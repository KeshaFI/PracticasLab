import 'package:flutter/material.dart';
import 'package:app_pokemon/battle_logic.dart';

void main() {
  runApp(const PokemonApp());
}

class PokemonApp extends StatelessWidget {
  const PokemonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Batalla Pokémon',
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
      ),
      home: const BattleScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

//pantalla
class BattleScreen extends StatefulWidget {
  const BattleScreen({super.key});

  @override
  State<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends State<BattleScreen> {
  late Pokemon pokemonUsuario;
  late Pokemon pokemonRival;
  late Batalla batalla;
//Controlador para scroll automático
  final ScrollController _scrollController = ScrollController();

  List<Item> mochila = [
    Item(nombre: 'Poción', cantidadCuracion: 50),
    Item(nombre: 'Superpoción', cantidadCuracion: 100),
  ];

  //Guarda los mensajes en una lista
  List<String> battleLog = ['¡La batalla ha comenzado!'];

  //initState crea objetos una vez solo cuando la pantalla se crea
  @override
  void initState() {
    super.initState();
    //Crea los objetos de la lógica
    _inicializarBatalla();
  }

  void _inicializarBatalla() {
    //Crea los ataques
    var lanzallamas = Ataque(nombre: 'Lanzallamas', tipo: TipoPokemon.FUEGO, poder: 90);
    var placaje = Ataque(nombre: 'Placaje', tipo: TipoPokemon.NORMAL, poder: 30);
    var pistolaAgua = Ataque(nombre: 'Pistola Agua', tipo: TipoPokemon.AGUA, poder: 40);

    //Crea los pokemon usando la nueva propiedad con el imagePath
    pokemonUsuario = Pokemon(
      nombre: 'Charizard',
      tipo: TipoPokemon.FUEGO,
      hp: 300,
      velocidad: 100,
      ataques: [lanzallamas, placaje],
      //ruta de pubspec.yaml
      imagePath: 'assets/imagenes/charizard.png', 
    );
    pokemonRival = Pokemon(
      nombre: 'Blastoise',
      tipo: TipoPokemon.AGUA,
      hp: 230,
      velocidad: 78,
      ataques: [pistolaAgua, placaje],
      imagePath: 'assets/imagenes/blastoise.png',
    );
    
    //Crea la batalla
    batalla = Batalla(pokemonUsuario: pokemonUsuario, pokemonRival: pokemonRival);
    print("Batalla inicializada. ${batalla.atacanteActual.nombre} ataca primero.");
  }

  void _scrollToBottom() {
    // Esperamos un milisegundo para que la lista se renderice y luego bajamos
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }
//Mostrar la mochila
  void _abrirMochila() {
    // Si no es mi turno o terminó la batalla, no abrir
    if (batalla.atacanteActual != pokemonUsuario || pokemonUsuario.hp == 0 || pokemonRival.hp == 0) return;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return SimpleDialog(
          title: const Text('Elige un objeto', style: TextStyle(color: Colors.blue)),
          children: mochila.map((item) {
            return SimpleDialogOption(
              onPressed: () {
                Navigator.pop(context);
                _usarObjeto(item);
              },
              child: Text('💊 ${item.nombre} (+${item.cantidadCuracion} HP)'),
            );
          }).toList(),
        );
      },
    );
  }

  void _usarObjeto(Item item) {
    setState(() {
      //El usuario usa el item
      List<String> logUsuario = batalla.usarItem(item);
      battleLog.addAll(logUsuario);
    });
    _scrollToBottom();
    //Turno del rival
    if (pokemonRival.hp > 0) {
      Future.delayed(const Duration(milliseconds: 1500), () {
        setState(() {
          List<String> logRival = batalla.realizarAtaque(pokemonRival.ataques[0]);
          battleLog.addAll(logRival);
        });
        _scrollToBottom();
      });
    }
  }

  //widget para la barra de vida
  Widget _buildHealthBar(Pokemon pokemon) {
    double porcentaje = pokemon.hp / pokemon.maxHp;
    
    //Color según el daño
    Color colorBarra = Colors.green;
    if (porcentaje < 0.5) colorBarra = Colors.yellow;
    if (porcentaje < 0.2) colorBarra = Colors.red;

    return Column(
      children: [
        Text(
          '${pokemon.nombre}  ${pokemon.hp}/${pokemon.maxHp}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white, shadows: [
            Shadow(offset: Offset(1.0, 1.0), blurRadius: 3.0, color: Colors.black),
          ]),
        ),
        const SizedBox(height: 5),
        SizedBox(
          width: 200,
          child: LinearProgressIndicator(
            value: porcentaje, // Valor entre 0 y 1
            backgroundColor: Colors.grey[300],
            color: colorBarra,
            minHeight: 10, // Grosor de la barra
            borderRadius: BorderRadius.circular(5),
          ),
        ),
      ],
    );
  }

@override //Todo esto se cambió una cantidad bien insana de veces
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          //Fondo, funciona como una capa, se va a ver abajo de todo
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/imagenes/fondo.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          //Los pokemones y el log se van a ver arriba del fondo
          SafeArea(
            child: Column(
              children: [
                // TÍTULO
                Container(
                  margin: const EdgeInsets.only(top: 10, bottom: 5),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white30),
                  ),
                  child: const Text(
                    "BATALLA POKÉMON",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      shadows: [Shadow(blurRadius: 5, color: Colors.blue)],
                    ),
                  ),
                ),

                //Área de combate
                SizedBox(
                  height: 500,
                  child: Stack(
                    children: [
                      //Para charizard
                      Align(
                        alignment: const Alignment(-0.4, 0.2),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildHealthBar(pokemonUsuario),
                            const SizedBox(height: 5),
                            Transform.scale(
                              scaleX: -1,
                              child: Image.asset(
                                pokemonUsuario.imagePath,
                                height: 130,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ],
                        ),
                      ),

                      //Blastoise
                      Align(
                        alignment: const Alignment(0.4, 0.1),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildHealthBar(pokemonRival),
                            const SizedBox(height: 5),
                            Image.asset(
                              pokemonRival.imagePath,
                              height: 130,
                              fit: BoxFit.contain,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                //Log
                Container(
                  height: 100,
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 20.0),
                  padding: const EdgeInsets.all(10.0),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.white54, width: 2),
                  ),
                  child: ListView.builder(
                    controller: _scrollController,
                    itemCount: battleLog.length,
                    itemBuilder: (context, index) {
                      bool esUltimo = index == battleLog.length - 1;
                      return Text(
                        battleLog[index],
                        style: TextStyle(
                          color: esUltimo ? Colors.yellowAccent : Colors.white,
                          fontSize: esUltimo ? 16 : 14,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          //Controles del jugador
          Positioned(
            left: 30,
            bottom: 30,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, // Alineado a la izquierda
              mainAxisSize: MainAxisSize.min,
              children: [
                //Mochila
                ElevatedButton.icon(
                  onPressed: _abrirMochila,
                  icon: const Icon(Icons.backpack),
                  label: const Text("MOCHILA"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),

                const SizedBox(height: 15),

                //Botones de ataque
                _buildAttackMenu(),
              ],
            ),
          ),

          //Boton para reiniciar, como una capa aparte porque está al centro
          // Usamos 'if' dentro de la lista de hijos del Stack
          if (pokemonUsuario.hp == 0 || pokemonRival.hp == 0)
            Align(
              //Alineado al centro abajo
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 30.0),
                child: ElevatedButton(
                  onPressed: _reiniciarBatalla,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 10,
                  ),
                  child: const Text(
                    'VOLVER A JUGAR',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  //Construye los botones de ataque basados en el Pokémon del usuario
Widget _buildAttackMenu() {
    bool batallaTerminada = (pokemonUsuario.hp == 0 || pokemonRival.hp == 0);
    List<Ataque> ataques = pokemonUsuario.ataques;
    List<Widget> botonesDeAtaque = [];

    for (var ataque in ataques) {
      botonesDeAtaque.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0), //Espacio entre botones
          child: ElevatedButton(
            onPressed: batallaTerminada ? null : () { _atacar(ataque); },
            style: ElevatedButton.styleFrom(
              // Alineamos el texto del botón a la izquierda
              alignment: Alignment.centerLeft,
              minimumSize: const Size(180, 40),
            ),
            child: Text('${ataque.nombre} (${ataque.tipo.name})'),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: botonesDeAtaque,
    );
  }
  //Lógica que se ejecuta al presionar un botón de ataque
  void _atacar(Ataque ataque) {

    //Por si alguien tiene 0 de vida, así no hace nada
    if (pokemonUsuario.hp == 0 || pokemonRival.hp == 0) {
      return;
    }
    if (batalla.atacanteActual == pokemonUsuario) {
      
      //setState notifica a Flutter que algo cambió en el estado
      setState(() {
      //Ejecuta y recibe el log del ataque del usuario
      List<String> logUsuario = batalla.realizarAtaque(ataque);
      battleLog.addAll(logUsuario);
      });
      _scrollToBottom();

      //Si el rival no se debilitó, hacemos que ataque
      if (pokemonRival.hp > 0) {
        //Espera para simular el turno del rival
        Future.delayed(const Duration(milliseconds: 1500), () {
          setState(() {
          List<String> logRival = batalla.realizarAtaque(pokemonRival.ataques[0]);
          battleLog.addAll(logRival);
          });
          _scrollToBottom();
        });
      }
    }
  }

  //Función para reiniciar la batalla
  void _reiniciarBatalla() {
    setState(() {
      _inicializarBatalla(); 
      battleLog = ['¡La batalla ha comenzado!'];
    });
  }
}