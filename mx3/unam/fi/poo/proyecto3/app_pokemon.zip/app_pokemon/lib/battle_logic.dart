enum TipoPokemon {
  FUEGO,
  AGUA,
  PLANTA,
  ELECTRICO,
  ROCA,
  NORMAL,
  LUCHA,
  VENENO,
  TIERRA,
  VOLADOR,
  PSIQUICO,
  BICHO,
  FANTASMA,
  DRAGON,
  DARK,
  STEEL 
}
const Map<TipoPokemon, Map<TipoPokemon, double>> mapaDeTipos = {
  //Atacante
  TipoPokemon.NORMAL: {
    //Defensor
    TipoPokemon.ROCA: 0.5,
    TipoPokemon.FANTASMA: 0.0,
  },
  TipoPokemon.FUEGO: {
    TipoPokemon.FUEGO: 0.5,
    TipoPokemon.AGUA: 0.5,
    TipoPokemon.PLANTA: 2.0,
    TipoPokemon.BICHO: 2.0,
    TipoPokemon.ROCA: 0.5,
    TipoPokemon.DRAGON: 0.5,
  },
  TipoPokemon.AGUA: {
    TipoPokemon.FUEGO: 2.0,
    TipoPokemon.AGUA: 0.5,
    TipoPokemon.PLANTA: 0.5,
    TipoPokemon.TIERRA: 2.0,
    TipoPokemon.ROCA: 2.0,
    TipoPokemon.DRAGON: 0.5,
  },
  TipoPokemon.PLANTA: {
    TipoPokemon.FUEGO: 0.5,
    TipoPokemon.AGUA: 2.0,
    TipoPokemon.PLANTA: 0.5,
    TipoPokemon.VENENO: 0.5,
    TipoPokemon.TIERRA: 2.0,
    TipoPokemon.VOLADOR: 0.5,
    TipoPokemon.BICHO: 0.5,
    TipoPokemon.ROCA: 2.0,
    TipoPokemon.DRAGON: 0.5,
  },
  TipoPokemon.ELECTRICO: {
    TipoPokemon.AGUA: 2.0,
    TipoPokemon.PLANTA: 0.5,
    TipoPokemon.ELECTRICO: 0.5,
    TipoPokemon.TIERRA: 0.0,
    TipoPokemon.VOLADOR: 2.0,
    TipoPokemon.DRAGON: 0.5,
  },
  TipoPokemon.LUCHA: {
    TipoPokemon.NORMAL: 2.0,
    TipoPokemon.VENENO: 0.5,
    TipoPokemon.VOLADOR: 0.5,
    TipoPokemon.PSIQUICO: 0.5,
    TipoPokemon.BICHO: 0.5,
    TipoPokemon.ROCA: 2.0,
    TipoPokemon.FANTASMA: 0.0,
    TipoPokemon.DARK: 2.0,
  },
  TipoPokemon.VENENO: {
    TipoPokemon.PLANTA: 2.0,
    TipoPokemon.VENENO: 0.5,
    TipoPokemon.TIERRA: 0.5,
    TipoPokemon.BICHO: 1.0,
    TipoPokemon.ROCA: 0.5,
    TipoPokemon.FANTASMA: 0.5,
  },
  TipoPokemon.TIERRA: {
    TipoPokemon.FUEGO: 2.0,
    TipoPokemon.PLANTA: 0.5,
    TipoPokemon.ELECTRICO: 2.0,
    TipoPokemon.VENENO: 2.0,
    TipoPokemon.VOLADOR: 0.0,
    TipoPokemon.BICHO: 0.5,
    TipoPokemon.ROCA: 2.0,
  },
  TipoPokemon.VOLADOR: {
    TipoPokemon.PLANTA: 2.0,
    TipoPokemon.ELECTRICO: 0.5,
    TipoPokemon.LUCHA: 2.0,
    TipoPokemon.BICHO: 2.0,
    TipoPokemon.ROCA: 0.5,
  },
  TipoPokemon.PSIQUICO: {
    TipoPokemon.LUCHA: 2.0,
    TipoPokemon.VENENO: 2.0,
    TipoPokemon.PSIQUICO: 0.5,
    TipoPokemon.DARK: 0.0,
  },
  TipoPokemon.BICHO: {
    TipoPokemon.FUEGO: 0.5,
    TipoPokemon.PLANTA: 2.0,
    TipoPokemon.LUCHA: 0.5,
    TipoPokemon.VENENO: 0.5,
    TipoPokemon.VOLADOR: 0.5,
    TipoPokemon.PSIQUICO: 2.0,
    TipoPokemon.FANTASMA: 0.5,
    TipoPokemon.DARK: 2.0,
  },
  TipoPokemon.ROCA: {
    TipoPokemon.FUEGO: 2.0,
    TipoPokemon.TIERRA: 0.5,
    TipoPokemon.VOLADOR: 2.0,
    TipoPokemon.BICHO: 2.0,
    TipoPokemon.LUCHA: 0.5,
  },
  TipoPokemon.FANTASMA: {
    TipoPokemon.NORMAL: 0.0,
    TipoPokemon.PSIQUICO: 2.0,
    TipoPokemon.FANTASMA: 2.0,
    TipoPokemon.DARK: 0.5,
  },
  TipoPokemon.DRAGON: {
    TipoPokemon.DRAGON: 2.0,
  },
  TipoPokemon.DARK: {
    TipoPokemon.LUCHA: 0.5,
    TipoPokemon.PSIQUICO: 2.0,
    TipoPokemon.FANTASMA: 2.0,
    TipoPokemon.DARK: 0.5,
  },
};
//Define un ataque con su nombre, tipo y poder base.
class Ataque {
  String nombre;
  TipoPokemon tipo;
  //daño base
  int poder;

  Ataque({
    required this.nombre,
    required this.tipo,
    required this.poder,
  });

  @override
  String toString() {
    return '$nombre (Tipo: $tipo, Poder: $poder)';
  }
}
class Item {
  String nombre;
  int cantidadCuracion;

  Item({required this.nombre, required this.cantidadCuracion});
}
//Define un pokemon con sus características base.
class Pokemon {
  String nombre;
  TipoPokemon tipo;
  int hp;
  int velocidad;
  List<Ataque> ataques;
  //Reconoce imágenes
  String imagePath;
//recordar vida maxima
late int maxHp;
  Pokemon({
    required this.nombre,
    required this.tipo,
    required this.hp,
    required this.velocidad,
    required this.ataques,
    //para que sea obligatorio el path de la imagen, por esto prueba lógica marcará error
    required this.imagePath,
  }) {
    maxHp = hp;
  }
void curar(int cantidad) {
    hp += cantidad;
    if (hp > maxHp) {
      hp = maxHp; // No podemos tener más vida que el máximo
    }
  }
  @override
  String toString() {
    return '''
--- Pokémon Creado ---
Nombre: $nombre
Tipo: $tipo
HP: $hp
Velocidad: $velocidad
Ataques:
  - ${ataques[0].nombre}
  - ${ataques[1].nombre}
--------------------''';
  }
}

//Maneja la lógica de una batalla entre dos pokemon.
class Batalla {
  Pokemon pokemonUsuario;
  Pokemon pokemonRival;
  Pokemon? _atacanteActual;
  //getter para saber a quién le toca atacar, nunca será nulo
  Pokemon get atacanteActual => _atacanteActual!;
  Batalla({
    required this.pokemonUsuario,
    required this.pokemonRival,
  }) {
    _determinarPrimerAtacante();
  }

  void _determinarPrimerAtacante() {
    if (pokemonUsuario.velocidad >= pokemonRival.velocidad) {
      _atacanteActual = pokemonUsuario;
    } else {
      _atacanteActual = pokemonRival;
    }
    print('--- INICIA LA BATALLA ---');
    print('${_atacanteActual!.nombre} ataca primero (Velocidad: ${_atacanteActual!.velocidad})');
  }
  //Calcula el multiplicador de daño basado en los tipos
  double _calcularMultiplicador(TipoPokemon tipoAtaque, TipoPokemon tipoDefensor) {
    //Busca el mapa del tipo atacante
    var mapaAtacante = mapaDeTipos[tipoAtaque];
    if (mapaAtacante == null) {
      //Si el tipo atacante no tiene reglas especiales
      return 1.0;
    }

    //Busca el multiplicador para el tipo defensor
    var multiplicador = mapaAtacante[tipoDefensor];
    if (multiplicador == null) {
      //Si no hay regla especiales
      return 1.0;
    }
    return multiplicador;
  }
    //Ahora devuelve un Log de mensajes en lugar de imprimir en consola.
    List<String> realizarAtaque(Ataque ataque) {
      //Lista de mensajes para este turno
      List<String> logDelTurno = [];

      Pokemon defensor;
      if (_atacanteActual == pokemonUsuario) {
        defensor = pokemonRival;
      } else {
        defensor = pokemonUsuario;
      }

      //Calcula el multiplicador de tipo
      double multiplicador = _calcularMultiplicador(ataque.tipo, defensor.tipo);
      
      //Calcula el daño
      int damage = (ataque.poder * multiplicador).round();

      //Aplica el daño
      defensor.hp = defensor.hp - damage;
      if (defensor.hp < 0) {
        defensor.hp = 0;
      }
      //Añade mensajes al log en lugar de usar print()
      logDelTurno.add('>> ¡${_atacanteActual!.nombre} usa ${ataque.nombre}!');
      
      if (multiplicador == 2.0) {
        logDelTurno.add('>> ¡Es súper efectivo! (x2)');
      } else if (multiplicador == 0.5) {
        logDelTurno.add('>> No es muy efectivo... (x0.5)');
      } else if (multiplicador == 0.0) {
        logDelTurno.add('>> ¡No tiene efecto! (x0)');
      }

      logDelTurno.add('>> ${defensor.nombre} recibe $damage de daño.');
      logDelTurno.add('>> ${defensor.nombre} HP restante: ${defensor.hp}');
      //Para ver si la batalla terminó
      if (defensor.hp == 0) {
        logDelTurno.add('¡BATALLA TERMINADA! ${defensor.nombre} se ha debilitado.');
        logDelTurno.add('¡Ganador: ${_atacanteActual!.nombre}!');
      } else {
        _cambiarTurno();
        logDelTurno.add('Es el turno de ${_atacanteActual!.nombre}...');
      }
      
      //Devuelve todos los mensajes generados en este turno
      return logDelTurno;
    }

    List<String> usarItem(Item item) {
    List<String> logDelTurno = [];
    
    //cura el atacante actual
    _atacanteActual!.curar(item.cantidadCuracion);

    logDelTurno.add('>> ¡${_atacanteActual!.nombre} usa ${item.nombre}!');
    logDelTurno.add('>> Recupera ${item.cantidadCuracion} HP.');
    logDelTurno.add('>> HP actual: ${_atacanteActual!.hp}/${_atacanteActual!.maxHp}');

    //Cambiamos de turno cuando se usa
    _cambiarTurno();
    logDelTurno.add('Es el turno de ${_atacanteActual!.nombre}...');

    return logDelTurno;
  }

  void _cambiarTurno() {
    if (_atacanteActual == pokemonUsuario) {
      _atacanteActual = pokemonRival;
    } else {
      _atacanteActual = pokemonUsuario;
    }
    print('Es el turno de ${_atacanteActual!.nombre}...');
  }
}