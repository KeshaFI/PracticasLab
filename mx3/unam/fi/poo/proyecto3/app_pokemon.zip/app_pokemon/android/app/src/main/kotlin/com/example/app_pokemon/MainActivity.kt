package com.example.app_pokemon

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
